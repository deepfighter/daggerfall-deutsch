                             ____        __  __  __   
                            / __ )____ _/ /_/ /_/ /__ 
                           / __  / __ `/ __/ __/ / _ \
                          / /_/ / /_/ / /_/ /_/ /  __/
                         /_____/\__,_/\__/\__/_/\___/ 


                     a tamrielic board game for two player

==============================================================================
    ______________________
 -=/      INFO-TABLE      \=-
 *****************************************************************************
 ***  Battle, a tamrielic board game for two player                        ***
 *****************************************************************************
 *** Date Created:-  2008 - 2016                                           ***
 *** Edition:-       1.0 [First Release]                                   ***
 *** Created By:-    Killfetzer & Frank 'Deepfighter' Schwalb              ***
 *** e-mail:-        daggerfalldeutsch@gmail.com                           ***
 *** Website:-       http://battle.daggerfalldeutsch.de                    ***
 *****************************************************************************
 *** All content related to "Battle" is licensed under the Creative        ***
 *** Commons License Attribution-NonCommercial- NoDerivatives 4.0          ***
 *** International                                                         ***
 ***                                                                       ***
 *** License: http://creativecommons.org/licenses/by-nc-nd/4.0/deed.en     ***
 *****************************************************************************
 
 Dear players of "Battle",
 
 we are glad to show you our small project. After some groundwork the years
 before, we finally did it 2016 and implemented the basic game into reality.
 We have played some matches ourselces and it worked fine.
 
 More as that we have already further ideas for the next editions and
 modifications. The Battles in Tamriel are multifarious as you know. We would
 be glad for any feedback of yours, because we know that we can make the game
 better by playing it with different playing styles. As for that, please share
 your thoughts and opinions with us. You will get an answer for sure!
 
 Now, we can just wish you much fun while playing "Battle".
 
 Yours,
 Killfetzer & Deepfighter

==============================================================================