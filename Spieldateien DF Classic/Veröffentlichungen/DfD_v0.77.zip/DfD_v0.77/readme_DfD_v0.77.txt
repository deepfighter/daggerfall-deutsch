   ___                         ___      ____     ___           __          __
  / _ \___ ____ ____ ____ ____/ _/___ _/ / /____/ _ \___ __ __/ /____ ____/ /
 / // / _ `/ _ `/ _ `/ -_) __/ _// _ `/ / //___/ // / -_) // / __(_-</ __/ _ \
/____/\_,_/\_, /\_, /\__/_/ /_/  \_,_/_/_/    /____/\__/\_,_/\__/___/\__/_//_/
          /___//___/

==============================================================================
         Übersetzung / Translation

            ein Projekt von Frank 'Deepfighter' Schwalb and Numenorean

                                                für www.daggerfalldeutsch.de

==============================================================================
    _________________________
 -=/      INFO-TABELLE       \=-
 *****************************************************************************
 ***  The Elder Scrolls Chapter II: Daggerfall, README / LIESMICH          ***
 *****************************************************************************
 *** Projektbeginn:-       Oktober 2010                                    ***
 *** Letztes Update:-      Februar 2024 [Letzte Version für DF Classic]    ***
 *** Version:-             0.77 [pre-Alpha-Version]                        ***
 *** Gestartet von:-       Deepfighter & Numenorean                        ***
 *** E-mail:-              daggerfalldeutsch@gmail.com                     ***
 *** Übersetzer:-          Valentin 'Valdi' Winkler {Questübersetzer}      ***
 ***                       Greenlight {Textübersetzer}                     ***
 ***                       Klarix {QA Mainquest}                           ***
 *****************************************************************************
 *** The Elder Scrolls(R)                                                  ***
 *** (C)1993-2006 Bethesda Softworks LLC, a ZeniMax Media company. The     ***
 *** Scrolls, Bethesda Softworks, ZeniMax and their respective logos are   ***
 *** registered trademarks of ZeniMax Media Inc. All Rights Reserved.      ***
 ***                                                                       ***
 *** The Elder Scrolls II: Daggerfall(R)                                   ***
 *** (C)1994-1996 Bethesda Softworks LLC, a ZeniMax Media company. The     ***
 *** Elder Scrolls, Daggerfall, Bethesda, ZeniMax and their respective     ***
 *** logos are registered trademarks of ZeniMax Media Inc. All Rights      ***
 *** Reserved.                                                             ***
 ***                                                                       ***
 *** Deutsche-Übersetzung von The Elder Scrolls II: Daggerfall             ***
 *** (C) 2010-2024 Das deutsche Daggerfall-Übersetzungsteam                ***
 *** www.daggerfalldeutsch.de                                              ***
 ***                                                                       ***
 *****************************************************************************


 _                                                                          _
| |========================================================================| |
| |~~~~~~~~~~~~~~~~~ I N H A L T S V E R Z E I C H N I S ~~~~~~~~~~~~~~~~~~| |
|_|========================================================================|_|

    I. Einleitung . . . . . . . . . . . . . . . . . . . . . . . . . . [DFD-01]

   II. ChangeLog. . . . . . . . . . . . . . . . . . . . . . . . . . . [DFD-02]

       pre-Alpha 0.77
       Zukünftige Releases

  III. Systemvoraussetzung. . . . . . . . . . . . . . . . . . . . . . [DFD-03]

   IV. Installationsanleitung . . . . . . . . . . . . . . . . . . . . [DFD-04]

    V. Konfigurationsanleitung. . . . . . . . . . . . . . . . . . . . [DFD-05]

   VI. Bekannte Fehler/Bugs . . . . . . . . . . . . . . . . . . . . . [DFD-06]

  VII. Kontaktinformationen . . . . . . . . . . . . . . . . . . . . . [DFD-07]

 VIII. Credits and Acknowledgments. . . . . . . . . . . . . . . . . . [DFD-08]

   IX. Copyright and Licensing Information. . . . . . . . . . . . . . [DFD-09]

    X. Appendixes . . . . . . . . . . . . . . . . . . . . . . . . . . [DFD-10]

       Zusatzdokumente
	     Offizielle deutschsprachige Boxart
       FAQ



##############################################################################
## Für das Springen zum gewünschten Bereich müsst Ihr lediglich das Such-   ##
## fenster im Programm Wordpad, Editor, Browser, Office-Programm öffnen.    ##
## Dies ist oftmals die Tastenkombination STRG + F. Dort gebt Ihr dann      ##
## lediglich den "Code" [DFD-XX] für den jeweiligen Bereich ein und springt ##
## hiernach automatisch zu dem gewünschten Punkt.                           ##
##############################################################################


==============================================================================
                     --------------------------------------
                                 I - EINLEITUNG
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-01] //
                                                               ''''''''''''

 Zunächst vielen Dank, dass Ihr Euch dafür entschieden habt unsere Übersetzung
 von 'The Elder Scrolls II: Daggerfall' zu spielen. Egal, ob Ihr ein Veteran,
 oder Neuling mit dem Spiel seid, Ihr werdet hoffentlich genauso viel Spaß
 damit haben, wie wir mit der Übersetzung. Daggerfall ist weit mehr als ein
 normales Spiel, es ist - meiner Meinung nach - ein Meilenstein der 
 Videospielgeschichte. Seiner Zeit (leider) viel zu weit voraus, ist dieses 
 ambitionierte Projekt unglücklicherweise auch daran gescheitert. Der 
 erzwungene Release im August 1996 war letztlich das Ergebnis einer zügigen 
 Veröffentlichung. Das hier unter hohem Druck versucht wurde, das Spiel 
 rechtzeitig zu veröffentlichen sieht man leider auch an vielen Stellen, so 
 z.B. an den hastig einkopierten Büchertexten, den vielen Fehlern in den 
 Quests oder die vielen Hinweise auf entfernte Inhalte im Spiel. Die 
 wesentlichen Fehler wurden von Fans bis heute schon behoben (z.B. durch den 
 in Daggerfall Deutsch integrierten DFQFIX). Einzig die geplante 
 deutschsprachige Übersetzung, welche aufgrund der technischen Schwierigkeiten 
 und der hohen Textlast gescheitert war (obgleich Julien LeFay auf Anfrage zu 
 uns einmal meinte, dass er es komplett übersetzt hätte und nicht wüsste, 
 weshalb es am Ende nicht in Deutschland veröffentlicht wurde), fehlt dem 
 deutschen Daggerfall-Spieler noch.
 
 Nun 14 Jahre nach der Veröffentlichung des Spieles hat sich eine engagierte
 Gruppe von The Elder Scrolls-Fans zusammengesetzt und sich dieser Aufgabe
 angenommen. Nach Hoch- und Tiefpunkten hat die Übersetzung seit November
 2012 wieder Fahrt aufgenommen durch den Beitritt von Numenorean, mit welchem
 ich die Übersetzung seitdem vorantreibe. Ein kompletter Relaunch und eine 
 vollständige Neuübersetzung der bisherigen Erstübersetzung hob das 
 sprachliche Niveau auf eine neue Ebene. Gleichzeitig wurde in den letzten 
 Jahren auch durch unsere Arbeit an Daggerfall Deutsch die 
 Übersetzungswerkzeuge, die vom französischen Übersetzungsprojekt (PFD) 
 internationalisiert und gepflegt werden, weiter angepasst und verbessert.
 
 Den bisherigen Stand könnt Ihr nun nachfolgend selbst spielen. Das
 Ziel war und ist nach wie vor eine stimmige und genaue Übersetzung
 bereitzustellen, die sich in die Elder Scrolls-Welt und den nachfolgenden
 Spielen konsistent eingliedert. Diesen Anspruch an die Übersetzung und uns
 selbst wollen wir gern mit jeder neuen Version aufrechterhalten.

 Die vorliegende Version ist unser aktueller Übersetzungsstand. Es ist eine
 "pre-Alpha Version". Das heißt diese ist zwar schon spielbar, aber noch 
 unfertig. Mit jeder Version gibt es mehr übersetzte Zeilen und Texte auf 
 Deutsch, welche oft aber noch nicht ausreichend getestet wurde, sodass wir 
 keine uneingeschränkte "Spielbarkeitsversicherung" abgeben können. Natürlich 
 ist dies langfristig unser Anspruch und es wird in unregelmäßigen Abständen 
 eine neue Version erscheinen die dann wieder neue deutschsprachige Inhalte 
 einfügt. Es ist uns zeitlich leider selbst nicht möglich unsere eigenen 
 Versionen zu spielen, weshalb wir auch auf Euch angewiesen sind. Solltet Ihr 
 Fehler finden die sich eingeschlichen haben, dann meldet Euch gerne bei uns 
 unter daggerfalldeutsch@gmail.com. Für alles weitere Verweise
 ich auf dieses Dokument, welches aufmerksam gelesen werden sollte.

	Wir wünschen Euch viel Spaß mit unserer Übersetzung.

                               	Das deutsche Daggerfall-Übersetzungsteam


 ------------------------------------------------------------------------------

 --------------------------------------------
  Update zu Version 0.77 (08. Februar 2024)
 --------------------------------------------
 
 Liebe Daggerfall-Freunde,
 wie im Blog angekündigt wird Daggerfall Deutsch für Classic/DOS nicht
 fortgeführt.  Das hat letztlich den Grund, dass zukünftig Daggerfall Unity,
 die präferierte Version des Spiels sein wird und es derzeit(!) keine Kapazitäten
 gibt, beide Varianten zu pflegen. Für die letzte Version haben wir uns dank der
 Hilfe von Krschkr die MAPS.BSA vorgenommen und fertiggestellt. Zudem hat Daneel53
 freundlicherweise Feritals Fix für die NPC Texturen (in der Provinz Hammerfall
 gibt es keine Bretonen mehr mit rothwardonsichen Namen) für Daggerfall Deutsch
 angepasst.

 Die kommende v0.80 wird dann ausschließlich für Daggerfall Unity erscheinen und
 nur damit spielbar sein. Dort wird dann auch aller weitere Fortschritt eingebaut
 sein, den es seit dem gibt.

 Beste Grüße,
 Deepfighter & Numenorean

 --------------------------------------------
  Update zu Version 0.76 (05. März 2021)
 --------------------------------------------
 
 Liebe Daggerfall-Freunde,
 wir haben Ende letzten Jahres unser 10-jähriges Jubiläum feiern dürfen. Mit
 dieser Version kommen wir dem Projektziel wieder ein Stück näher. In dieser
 Version haben wir dem Hauptquest eine letzte Aktualisierung unterzogen und
 diesen hier und da noch einmal sprachlich nachgeschliffen. Neu ist die
 Magiergilde, welche nun komplett auf Deutsch spielbar ist. All diese Texte
 finden sich im Übrigen jetzt auch im Tamriel-Almanach (www.tamriel-almanach.de),
 um auch die Finalität dieser zu untermauern.

 Beste Grüße,
 Deepfighter & Numenorean

 --------------------------------------------
  Update zu Version 0.75 (16. November 2019)
 --------------------------------------------
 
 Liebe Daggerfall-Freunde,
 zum ersten Mal mussten wir unseren jährlichen Veröffentlichungsrhytmus ad 
 acta legen und können nun nach gut über zwei Jahre später seit v0.73 eine 
 neue Version veröffentlichen. Diese beinhaltet vor allem Erweiterungen der 
 TEXT.RSC und eine komplette Übersetzung der FALL.EXE, was ein großer 
 Meilenstein (deshalb auch der größere Versionssprung) und eine große 
 Herausforderung auf vielen Ebenen war (siehe auch Beitrag im Blog). Zudem gab 
 es einen Fehler in der Originalversion der SPELLS.STD, welche deshalb noch 
 einmal neu angepasst werden musste. Ein weiterer Meilenstein war es die 
 Videofrequenzen in Daggerfall zu untertiteln. Das heißt, alle Videos sind nun 
 auch für jedermann verständlich. Eine Sprachausgabe ist "noch" nicht geplant, 
 könnte aber irgendwann mit Daggerfall Unity relevant werden.
 
 Apropos Daggerfall Unity: Wir sind hier ganz nah an der Entwicklung und
 werden, sobald alles für Übersetzungen implementiert wurde, diese auch 
 parallel anbieten. Bleibt gespannt.
  
 In der nächsten Version möchten wir die TEXT.RSC beenden (Näheres dazu im 
 Blog) und im besten Fall weitere Questsreihen hinzufügen. Schauen wir mal.

 Bis dahin viel Spaß beim Spielen und wenn Euch etwas auf dem Herzen liegt, 
 dann meldet Euch gerne jederzeit bei uns.

 Beste Grüße,
 Deepfighter & Numenorean


 ----------------------------------------
  Update zu Version 0.73 (23. Juli 2017)
 ----------------------------------------
 
 Liebe Daggerfall-Feunde,
 ein kleines Update, mit fünf weiteren nur in Daggerfall vorkommenden Büchern.
 Hierzu gehören die Bücher der Rothwardonenreihe von Destri Melarg, wie auch
 "Des Narren Ebenerz", ein Schauspiel, welches seine ganz eigenen "Momente" 
 hat. Zudem wurde DFQFIX v3.3 von PLRDF implementiert. Damit sind die bisher
 übersetzten Quests mit dem aktuellsten Bugfix nutzbar. Solltet Ihr einen
 Speicherstand seit v0.70 besitzen, so könnt Ihr es ohne Probleme weiter
 nutzen. Wenn Ihr ein neues Spiel anfangen wollt, so empfehlen wir Euch, dass
 Ihr bis zur nächsten Version wartet. Die v0.75 wird derartig viele Änderungen
 beinhalten, welche den alten Spielstand "unbrauchbar" machen wird.

 Das gesagt, wünschen wir Euch viel Spaß beim Lesen und Spielen!

 Beste Grüße,
 Deepfighter & Numenorean


 ------------------------------------------
  Update zu Version 0.72 (28. August 2016)
 ------------------------------------------
 
 Liebe Daggerfall-Feunde,
 ein kleiner, aber feiner Release steht an. Insgesamt 33 übersetzte Bücher und
 die Quests der Hexenzirkel stehen nun zum Lesen und Spielen bereit. Zudem 
 einige Korrekturen im Mainquest und ein paar weitere Text- und 
 Formatierungsanpassungen. Gezogen hat sich der Release aufgrund unserer 
 Nebenprojekte. Wir haben innerhalb von sechs Monaten ein 
 Übersetzungskompendium zu Elder Scrolls geschaffen, welches nicht nur allen 
 Moddern, sondern auch Lore-Interessierte und zukünftigen Übersetzern helfen 
 soll. Es hilft auch uns in gewisser Weise bei Daggerfall Deutsch, weshalb wir 
 uns auch entschieden haben für die nächste Version, um als gutes Beispiel 
 voranzugehen, einige Übersetzungsanpassungen vorzunehmen. Hierzu werden wir 
 Euch im Blog nochmal gesondert zu informieren. In der nächsten Version, soll 
 dann wieder eine neue Questreihe (Magiergilde) folgen.

 Nun Euch viel Spaß beim Spielen.

 Beste Grüße
 Deepfighter & Numenorean


 ------------------------------------------
  Update zu Version 0.71 (5. Oktober 2015)
 ------------------------------------------
 
 Liebe Daggerfall-Freunde,
 etwas länger hat es nun doch gedauert, aber wir sind stolz Euch einige neue
 Inhalte präsentieren zu können. Neben den üblichen Bug- und Formatierungs-
 Fixes sind die größten Neuerungen die Übersetzungen der magischen Effekte,
 wie auch die Hinzufügung der beiden Questreihen der 16 Daedrafürsten, sowie
 die Heilungsquests für Vampirismus und Lykanthropie. Vor allem letztere sind
 mit vielen Variablen ausgestattet gewesen, was das Übersetzen nicht immer
 einfach gemacht hat. Deshalb muss durch testen und spielen versucht werden die
 noch vorhandenen Fehler auszumerzen. Besondere Beachtung galt auch den Daedra-
 Quests, welche wir mit viel Arbeit und Bedacht übersetzt haben, um die
 originale Stimmung der Fürsten auch so gut es geht ins Deutsche zu übertragen.
 Lasst Euch einfach überraschen, wenn Ihr die Daedra an Ihrem Beschwörungstag
 rufen lasst.

 Ein weiterer Meilenstein ist die komplette Übersetzung der Ortschaften des
 Gebiets Daggerfall (Dolchsturz). Ab sofort sind alle 1330 Ortschaften dieser
 Region eingedeutscht. Da einige Spieler es schaffen die Daggerfall-Region
 niemals wirklich zu verlassen, war dies uns besonders wichtig zeitnah
 einzufügen.

 Damit sind die meisten Änderungen erklärt. Wie schon gesagt gibt es viele
 kleinere Sachen in den anderen Quests die noch etwas angepasst wurden.

 Als Bonus habe ich für die guten alten Rollenspieler unter Euch einige
 Dokumente erstellt, wie einen Charakterbogen, Inventarliste, Questbuch
 oder ein Zauberbuch. Diese könnt Ihr gerne ausdrucken und neben dem Spielen
 benutzen. Zusätzlich liegt noch ein CD-Rom Cover für das Spiel bei, welches
 freundlicherweise von Raubkopiesäbel zur Verfügung gestellt wurde.

 Nun viel Spaß beim Spielen und bis zur nächsten Version.

 Grüße
 Euer Daggerfall-Übersetzungsteam


 -------------------------------------------
  Update zu Version 0.70 (1. November 2014)
 -------------------------------------------
 
 Liebe Daggerfall-Freunde,
 nach unserem Relaunch mit Version 0.65 versorgen wir Euch nun mit einer
 neuen Version. Ausführungen zum Relaunch findet Ihr etwas weiter unten bei
 "Update zu Version 0.65".

 Diese Version ergänzt die Vampirquests (noch ungetestet) und verbessert
 einige Formatierungen im Spiel. Zusätzlich gibt es fünf neue Bücher und
 die Beschreibungen der Zaubereffekte auf Deutsch.

 Als Besonderheit in dieser Version haben wir begonnen die Ortschaften
 zu übersetzen. Alles westlich der Drachenschwanz-Berge {Dragontail
 Mountains} inklusive Sentinel sind deutschsprachig. Das war eine Menge
 Arbeit, aber wir freuen uns Euch jetzt das Ergebnis präsentieren zu
 können. In jeder kommenden Version werden nach und nach weitere Gebiete
 erschlossen. Wir würden gerne Daggerfall in die nächste Version integrieren,
 da dies die Region ist in welche jeder Spieler mit dem Spiel startet.

 Viele kleinere Änderungen, vor allem kosmetischer Natur, oder Umlaut-Fehler
 wurden ebenfalls beseitigt. Außerdem haben wir uns entschieden mit
 kleineren Release-Zyklen fortzusetzen. Ihr werdet also häufiger
 aktualisieren dürfen, dafür aber auch zeitiger neue Inhalte spielen können.

 Ihr könnt die Version übrigens einfach auf Eure vorhandene Version
 überschreiben. Fallen Euch Fehler auf, dann zögert nicht diese an
 daggerfalldeutsch@gmail.com zu senden.
 Für Änderungen von Version 0.61 auf 0.65 siehe den nächsten Punkt.

 Viel Spaß beim Spielen und bis zur nächsten Version.

 Grüße
 Euer Daggerfall-Übersetzungsteam


 ----------------------------------------
  Update zu Version 0.65 (11. Juni 2014)
 ----------------------------------------
 
 Liebe Daggerfall-Freunde,
 nach der eher unglücklichen Version 0.60/0.61 im Herbst 2012 gab es Ende des
 selben Jahres eine Art "Relaunch" mit Konzentration auf Qualität statt
 Quantität. Auf Basis der vorangegangenen Erstübersetzungen und mit einem
 kleineren Team haben wir uns daran gemacht die deutsche Übersetzung von The
 Elder Scrolls II: Daggerfall voranzutreiben und schlussendlich auch zu
 beenden.

 In v0.60/0.61 gab es einige Sachen die es in dieser Version nicht
 gibt. Diese Sachen werden jedoch in den nachfolgenden Versionen nacheinander
 hinzugefügt. Dies hängt einfach daran, dass sich alles einer erneuten Prüfung
 und ggf. Neuübersetzung durchziehen muss. Wir haben jeden Stein umgedreht, um
 am Ende eine stimmige und qualitativ hochwertige Übersetzung zu
 gewährleisten, sodass dieser Quantitätsverlust, durch einen Qualitätsgewinn
 ausgeglichen wird.

 Die Konzentration in dieser Version lag auf dem Mainquest. Diese Quests
 machen, wie in den nachfolgenden Teilen auch, zwar eher einen geringen Teil
 des Gesamtspiels aus, ist jedoch Lore-trächtig und hat für die Geschichte
 einen nicht unerheblichen Wert. Für uns stand demnach zügig fest, dass wir
 mit diesem anfangen wollen. Und er ist dank der Mühen jedes Einzelnen richtig
 gut geworden.

 Weiterhin haben wir knapp 1/7 questunabhängiger Texte/Dialoge übersetzt,
 sodass beim Spielen zwar vieles noch auf Englisch ist, hier und da sich aber
 doch ein deutscher Satz mal finden lässt. Auch die Grafiken wurden bis auf
 wenige Ausnahmen, wo es bei meinem Kurztest nicht ganz funktionierte,
 integriert und sind von Ihrer Anzahl noch üppiger als in der
 Vorgängerversion.

 Bezüglich dem Spielen der Quests möchte ich kurz noch ergänzen, dass Ihr,
 auch wenn nicht empfohlen, nicht unbedingt ein neues Spiel anfangen braucht.
 Schon gespielte Quests bleiben zwar auf Englisch, neu angefangene Quests des
 Hauptstranges werden jedoch auf Deutsch spielbar sein. Hierzu müsst Ihr, damit
 keine Fehler auftreten, einzig alle aktiven Quests beenden oder abbrechen.

 Es wird dazu kommen, dass Ihr (noch) neben dem vielen Deutsch-Englisch
 Gemisch auch noch einige Bugs/Unstimmigkeiten im Spiel finden werdet. Das ist
 normal und liegt an der Natur eines Spieles dieser Dimension. Daggerfall
 Deutsch enthält den aktuellsten (offiziellen) Patch und alle in sich
 kompatiblen Bugfixes die es zurzeit gibt. Man möge bitte Bedenken, dass das
 Spiel vor 18 Jahren erschienen ist und wir damals eine andere Art von
 Videospielindustrie hatten. Aus diesem Grund nicht entmutigen lassen, sollte
 ein Quest mal zerbrochen sein. Dies dürfte nur bei einzelnen auftreten und
 der Mainquest sollte problemlos spielbar sein.

 Solltet Ihr Fehler finden, so scheut Euch nicht diese uns mitzuteilen. Am
 besten mit Screenshot, und wenn nicht dann versuchen so genau wie möglich zu
 beschreiben, dann versuchen wir den Fehler selber zu reproduzieren. Und
 natürlich zu beheben.

 Als Besonderheit ggü. dem Originalspiel haben wir uns die Freiheit erlaubt
 ein paar "neutrale" Ergänzungen dem Spiel hinzuzufügen um den doch oft
 wiederholenden Sätzen der Bürger entgegenzuwirken und mehr Vielfalt in die
 Dialoge zu bekommen. An der Geschichte oder der Lore wurde nichts geändert.
 Dies wird über die nächsten Versionen immer wieder erweitert, sodass Euch
 nicht jeder mit "Willkommen" begrüßt.

 Wir hoffen, Ihr habt viel Spaß beim testen und freuen uns Euch schon bald
 weitere Inhalte bereitstellen zu können.

 Viele Grüße
 Euer Daggerfall-Übersetzungsteam


==============================================================================
                     --------------------------------------
                                 II - CHANGELOG
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-02] //
                                                               ''''''''''''


                      / =============================== \
                    <     Version 0.55 'Dugong Dung'      >
                      \ =============================== /


  Erstkorrektur
  -------------

 * Quests der Dunklen Bruderschaft
 * Quests der Kriegergilde
 * Quests der Magiergilde
 * Quests der Tempel der Acht Göttlichen
 * 2/3 der Hauptquest
 * Eine Textdatei (FLATS.CFG)
 * 2 Ingame-Bücher ("Die erste Schriftrolle von Baan Dar" und "Die Schweine-
   kinder")


                      / =============================== \
                    <     Version 0.60 'Drunken Dragon'   >
                      \ =============================== /


 * Alle Quests übersetzt



                      / =============================== \
                    <            Version 0.61             >
                      \ =============================== /

 * Fix um durch die Charaktererstellung zu kommen. Spiel ist vorher 
   eingefroren.



                    / ==================================== \
                  <    Version 0.65 'Daggerless Developer'   >
                    \ ==================================== /

                             ~  R E L A U N C H ~


 * Übersetzung des Mainquests
 * 25 deutsche Bücher
 * 73 Grafiken eingedeutscht
 * 1/6 aller questunabhängigen Texte übersetzt
 * Fragen zur Biografie während der Charaktererstellung übersetzt
 * Zaubersprüche übersetzt
 * Kreaturen übersetzt



                    / ==================================== \
                  <       Version 0.70 'Debunk Dracula'      >
                    \ ==================================== /

 * Übersetzung der Vampirquests
 * 5 neue Bücher
 * Übersetzung Ortschaften westlich der Drachenschwanz-Berge (Dragontail
   Mountains)
 * Übersetzung weiterer textunabhängigen Texte


                    / ==================================== \
                  <       Version 0.71 'Destitute Daedra'    >
                    \ ==================================== /

 * Übersetzung der Heilungs- und Daedra-Quests
 * Übersetzung Ortschaften Daggerfall
 * Übersetzung weiterer textunabhängiger Texte (u.a. Magische Effekte und
   Rassenbeschreibungen).


                               / ============== \
                             <    Version 0.72    >
                               \ ============== /

 * Übersetzung Quests der Hexenzirkel
 * 33 übersetzte Bücher

                               / ============== \
                             <    Version 0.73    >
                               \ ============== /

 * 10 übersetzte Bücher
 * Update mit DFQFIX v.3.3

                               / ============== \
                             <    Version 0.75    >
                               \ ============== /

* Komplette FALL.EXE (Gegenstände/Objekte, kleine Textfetzen) übersetzt.
** Das ist ein Meilenstein (deshalb auch der größere Versionssprung), der sich
   erheblich im Spiel bemerkbar machen wird.
* Videos (inklusive Intro) sind übersetzt!
* Weitere Texte (Gildenaufstiege, Klassenbeschreibungen, Artefakttexte, Feier-
  tage)

                               / ============== \
                             <    Version 0.76    >
                               \ ============== /

* Komplette Überarbeitung des Mainquests
* Übersetzung der Magiergilde

                               / ============== \
                             <    Version 0.77    >
                               \ ============== /

* Alle Ortschaften (MAPS.BSA) übersetzt
* Inkludiert Hammerfell NPC fix von Ferital: Korrigiert NPC Texturen in
  Hammerfall + Drachenschwanzbergen [-> Keine Bretonen mehr mit rothwardonischen
  Namen] (mit Dank an Daneel53 für die Umsetzung)


                      / =============================== \
                    <          Zukünftige Releases        >
                      \ =============================== /

 * bis Version 0.80 / Geplante Inhalte:

	- Weitere deutsche Bücher.
	- Übersetzung weiterer Quests.
	- Weitere Abschnitte der TEXT.RSC, welche Dialoge und andere Ingame-Texte
    beinhalten.
	- Fix der restlichen Grafiken.
  - Eventuell auch Übersetzung der Texturen. (Hilfe benötigt)


==============================================================================
                     --------------------------------------
                            III - SYSTEMVORAUSSETZUNG
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-03] //
                                                               ''''''''''''

 Originalspiel:

 Betriebssystem: MS-DOS 6.0
 Rechner: IBM oder kompatibler PC
 Prozessor: Pentium 486MHz
 RAM: 8 MB
 Festplatte: 50 MB frei Peripherie: 2xCD-ROM, VGA-Grafikkarte mit 265 Farben,
 Soundkarte, Tastatur, Maus

 Durch die DOSBox sind diese Voraussetzungen obsolet.



==============================================================================
                     --------------------------------------
                           IV - INSTALLATIONSANLEITUNG
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-04] //
                                                               ''''''''''''

 Updaten
 -------
   1. Ladet "DfD_v0.77" herunter.
   2. Kopiert den ARENA2-Ordner in den ARENA2-Ordner des Spiels und lasst
      alle Dateien ersetzen.
   3. Kopiert die FALL.EXE und ersetzt Sie mit der Originaldatei.


 DaggerfallSetup
 ---------------
   1. Ladet Euch "DaggerfallSetup" herunter.
   2. Folgt den Einstellungen wählt bei den optionalen Inhalten Daggerfall
      Deutsch aus, sowie die Bugfixsammlung DFQFIX und nehmt ggf. die Inhalte
	    hinzu, welche Ihr für nötig erachtet. Einige dieser Fixes und AddOns sind
	    multilingual und andere nicht. Ihr könnt Sie trotzdem nutzen, wenn Ihr
	    wollt. Eine Übersetzung der meisten Modifikationen ist bereits in den
      Dateien vorhanden (z.B. DFQFIX und DFBIOGFIX) oder wird nach Beendigung
      der Hauptübersetzung folgen.


 Manuelle Installation
 ---------------------
   1. Zunächst sollte die Vollversion von Daggerfall heruntergeladen und
      (inklusive des mitgelieferten Patchs) installiert werden. Dazu
      empfiehlt sich der deutschsprachige Daggerfall-Almanach von Deepfighter,
      der auch einen hervorragenden Einstieg in die Welt von Daggerfall
      bildet. Falls Ihr Daggerfall auch noch in der Originalsprache genießen
      möchte, ist es eventuell sinnvoll, ein zweites Daggerfall (~ 479 MB)
      unter einem anderen Dateipfad zu installieren (zB. "C:\dosgames\
      Daggerfall-Deutsch\...").

   2. Nun kann "DFD_v0.77" heruntergeladen werden. Um das ZIP-Archiv zu
      öffnen, benötigt Ihr z.B. WinRAR oder 7-ZIP. Am besten kopiert Ihr 
      einfach die Dateien entsprechend der Struktur. Die FALL.EXE
	    im Oberverzeichnis überschreiben und den ARENA2-Ordner aus dem Download
	    in sein Daggerfall-Hauptverzeichnis. 
            
      Dies empfiehlt sich vor allem für Mac- und Linuxnutzer, die eine 
      .exe-Anwendung nicht ausführen können.

      Leider gibt es unter Linux das Problem, dass ein einfaches Kopieren und 
      Einfügen nicht funktioniert, da es Case Sensitive ist und damit nicht
      ersetzt, sondern manche Dateien doppelt vorhanden sind, wo man bisher 
      noch manuell löschen muss. Ich überlege mir noch eine Lösung - beachtet 
      hierfür den Blog!

==============================================================================
                     --------------------------------------
                           V - KONFIGURATIONSANLEITUNG
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-05] //
                                                               ''''''''''''

 Eine spezifische Konfiguration nach der Installation ist aktuell noch nicht,
 nötig. Wer eine Desktopverknüpfung anlegen möchte schaut in den Daggerfall-
 Almanach (Suchformel: SHCU), oder nutzt DaggerfallSetup.

 Anpassungen im Spiel wären z.B. die Steuerung, ob Ihr Blickrichtungs-basiert
 oder Sicht-basiert steuern wollt. Ob Ihr mit Vollbild oder mit
 Übersichtsleiste spielen wollt. Dies könnt Ihr alles im Spiel beim Aufrufen
 des Menüs individuell einstellen.

 Shift + 2 = Ä
 Shift + 3 = ä
 Shift + 3 = Ö
 Shift + 7 = ö
 Shift + 8 = ß
 Shift + ü = Ü
 Shift + * = ü


==============================================================================
                     --------------------------------------
                            VI - BEKANNTE FEHLER/BUGS
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-06] //
                                                               ''''''''''''

 - Bei der Ersetzung laufender Quests können schwere Bugs auftreten. Deswegen
   sollte ein neues Spiel gestartet oder gewartet werden, bis die Quest
   abgeschlossen ist. Dies gilt aktuell NUR FÜR ALLE ÜBERSETZTEN QUESTS!
   Alle anderen Quests sind noch unverändert und können weiter gespielt werden.
   Schon gespielte Aufträge des Mainquests bleiben auf Englisch. Die Tagebuch-
   einträge dieser gespielten Quests bleiben demnach auch auf Englisch. Erst
   die neueren werden durch Daggerfall Deutsch deutschsprachig.

 - Es kann möglich sein, dass einige Grafiken noch kleinere Fehler in der
   Positionierung aufweisen können bzw. einige noch auf Englisch sind. Dies
   wird dann in einer der nächsten Versionen ausgebessert.

 - Bei einigen Questtexten und/oder Büchern können noch verschiedene
   Formatierungsschwierigkeiten auftauchen d.h. Zeilen zu lang, zu kurz,
   Umbrüche die nicht passen, etc. Diese am besten bei uns melden, ggf. auch
   mit Screenshot, damit wir dies für die nächste Version beheben können.

 . Es kommt regelmäßig vor, dass bei der Auswahl von Dienstleistungen (wie
   bsp. dem Erstellen von Zaubern) ein Zusatztext a la "Ihr seid gesund"
   auftaucht. Dies ist ein noch nicht behobener Fehler.


==============================================================================
                     --------------------------------------
                            VII - KONTAKTINFORMATIONEN
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-07] //
                                                               ''''''''''''

 Projektseite: www.daggerfalldeutsch.de

 Die offizielle Kontaktadresse lautet: daggerfalldeutsch@gmail.com

 Deepfighter: deepfighter@tamriel-almanach.de



==============================================================================
                     --------------------------------------
                       VIII - CREDITS AND ACKNOWLEDGMENTS
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-08] //
                                                               ''''''''''''

  An solch einem Projekt wirken eine Menge Menschen mit. Über die Zeit
  kristallisiert sich jedoch ein Kern heraus. Ich möchte demnach folgende
  Personen und Institutionen herausstellen. Ich danke:

 - Bethesda Softworks für The Elder Scrolls II: Daggerfall, im speziellen
   Julien LeFay und Ted Peterson, die wahren Köpfe und Väter hinter der
   Spielreihe The Elder Scrolls. Chapeau!.

 - Eric Heberling für den stimmigen Soundtrack der ersten beiden Spielteile.

 - Cato d. Ä., Archaeon, Ricardo Diaz und Killfetzer für die deutschen
   Versionen zahlreicher Ingame-Bücher aus Daggerfall, welche den Grundstock
   boten, um Sie Lore-stimmig und einheitlich zu überarbeiten.

 - Johannes18 aka Raubkopiesäbel als "Mann für alles". Mit seiner Hilfs-
   bereitschaft und enormen Ausdauer hat er uns viel Arbeit abgenommen, wenn es
   um die "langweiligeren" Arbeiten ging. Außerdem einen Riesendank für die
   toll erstellten Hüllencover für Daggerfall. Dank Dir!

 - dem Projekt PDLF und dort insbesondere Porygon, Ancestral Ghost und 
   Daneel53, welche durch Ihre Hilfestellungen und Erfahrungen mit der
   französischen Version uns viel Ärger und Zeit erspart haben. Merci beaucoup!

 - Burkhard Müller, der vor allem, aber nicht ausschließlich, mit seinem 
   Questeditor, der eine integrierte Vorschaufunktion besitzt, die Arbeit 
   erheblich erleichtert hat. Er hat uns seine Arbeiten an Daggerfall 
   dankenswerterweise überlassen.

 - Crashtestgoblin als Projekt(mit)initiator und kritisches Auge. Sein
   ausscheiden aus zeitlichen Gründen war sehr schade. Im gleichem Atemzug
   auch Boby und MadDin für deren Erstversuche sich mit den Grafiken und der
   problematischen FALL.EXE auseinanderzusetzen.

 - Valentin Winkler gilt mit mein größter Dank. Ohne Ihn wäre das Projekt schon
   Mitte 2012, vor seinem Relaunch auseinandergefallen. Hätte er nicht so
   kontinuierlich weiter an den Quests übersetzt wären wir heute nicht dort,
   wo wir sind. Vielen, vielen Dank.

 - Kschkr für seine Hilfe mit der MAPS.BSA

 - Numenorean - er weiß schon warum.

 - Idrachod für sein stetiges finden von neuem und längst vergessenen
   Daggerfall-Content.

 - All die Übersetzer, welche einen Teil zu der Erstversion (bis Ver. 0.61)
   beigetragen haben.

==============================================================================
                -----------------------------------------------
                    IX - Urheberrechte & Lizenzinformationen
                  --------------------------------------------
==============================================================================
                                                              \\ [DFD-09] //
                                                               ''''''''''''

 The Elder Scrolls(R)
 (C)1993-2006 Bethesda Softworks LLC, a ZeniMax Media company. The
 Scrolls, Bethesda Softworks, ZeniMax and their respective logos are
 registered trademarks of ZeniMax Media Inc. All Rights Reserved.

 The Elder Scrolls II: Daggerfall(R)
 (C)1994-1996 Bethesda Softworks LLC, a ZeniMax Media company. The
 Elder Scrolls, Daggerfall, Bethesda, ZeniMax and their respective
 logos are registered trademarks of ZeniMax Media Inc. All Rights
 Reserved.

 Deutsche-Übersetzung von The Elder Scrolls II: Daggerfall
 (C) 2010-2024 Das deutsche Daggerfall-Übersetzungsteam
 www.daggerfalldeutsch.de

 Dieses ZIP-File und alle darin enthaltenen Dateien dürfen nur im Gesamtpaket
 nicht kommerziell weiterverbreitet werden. Der offizielle und aktuellste
 Download befindet sich immer unter:

                    www.daggerfalldeutsch.de

 Möchte jemand die Übersetzung auf seiner Seite hosten, schreibt er mich bitte
 an und wir klären die Details. Offiziell wird für diese Version kein weiterer
 Hoster angeboten. DaggerfallSetup unter Leitung von Daneel53 (und ehemals 
 Ancestral Ghost) hat ausdrückliche Erlaubnis zur Nutzung, wie auch
 elderscrollsportal.de.


==============================================================================
                     --------------------------------------
                                 X - APPENDIXES
                       ----------------------------------
==============================================================================
                                                              \\ [DFD-10] //
                                                               ''''''''''''

                            / ===================== \
                          <      Zusatzdokumente      >
                            \ ===================== /

 Als Bonus habe ich für die guten alten Rollenspieler unter Euch einige
 Dokumente erstellt, wie einen Charakterbogen, Inventarliste, Questbuch
 oder ein Zauberbuch. Diese könnt Ihr gerne ausdrucken und neben dem Spielen
 benutzen. Zusätzlich liegt noch ein CD/DVD-Rom Cover für das Spiel bei, 
 welches freundlicherweise von Raubkopiesäbel zur Verfügung gestellt wurde.

 Zusätzlich liegt auch die aktuelle Version des Daggerfall-Almanachs bei. An
 Version 2.0, die dann auch mit den deutschen Begriffen arbeiten wird,
 wird weiterhin fleißig gearbeitet.


                      / =============================== \
                    <     Offizielle deutsche Boxart      >
                      \ =============================== /


 Weltreisen einmal anders, mit diesem Echtzeit Fantasyrollenspiel!

 Reisen Sie in die Welt von Tamriel, in der Mythen und Legenden zum Leben
 erwachen. In dieser in Echtzeit dargestellten dreidimensionalen Welt, können
 Sie sich völlig frei durch finstere Verliese und prächtige Schlösser bewegen.
 Diese Orte werden von Ausgeburten der Hölle bewohnt, die jedem Normal-
 sterblichen das Blut vor Angst in den Adern gefrieren lassen.
 Doch Sie sind alles andere als ein Normalsterblicher.
 Sie sind fest entschlossen die Mission erfolgreich zu beenden, auf die der
 Monarch von Daggerfall Sie gesandt hat.
 Ausgestattet mit einer Vielzahl an mächtigen Zaubersprüchen sowie der
 Fähigkeit neue Zaubersprüche zu kreieren, machen Sie sich auf die
 gefährliche Reise und erkunden Tausende von Orten und Städten, in der
 üer 80.000 Quadratkilometer großen Welt von Tamriel.
 Lernen Sie die unterschiedlichsten Menschen kennen.
 Aus Freunden können schnell mächtige Feinde werden.
 Achten Sie also auf Ihre Wortwahl, denn jeder Einzelne wird sich an Sie
 erinnern. Horchen Sie Ihre Gesprähspartner über Intrigen, Liebschaften,
 Bündnisse und Verschwörungen aus.

 Denken Sie immer daran: Wissen ist Macht und Unwissen kann tödlich sein,
 im Königreich von Daggerfall.

 Features
 --------

  - Spezial Effekte wie Light Sourcing und verschiedene Witterungsverhältnisse
    schaffen einen beispiellosen Realismus
  - Mehr als 80.000 Quadratkilometer Terrain zu erforschen
  - Lernen Sie über 5.000 Städte und Orte kennen
  - Erkunden Sie mehr als 5.000 Verliese, Kerker, Tempel Friedhöfe und
    Schlösser
  - 200 Ministories, die für langanhaltenden Spielspaß sorgen
  - Flexibeles Magiesystem erlaubt Ihnen das Erstellen eigener Zaubersprüche
  - Dutzende verschiedene Spielausgänge möglich
  - Wollten Sie schon immer einmal einen bösen Charakter darstellen? Kein
    Problem, dank der 128 möglichen Charaktereinstellungen

 -- Entnommen aus dem deutschen Boxart, das Spiel selber war auf Englisch --



                      / =============================== \
                    <                 FAQ                 >
                      \ =============================== /


 Ihr habt Fragen, Anregungen, Probleme zu der Übersetzung?

 Dann schreibt dies in unser Forum bzw. kontaktiert uns über
 die oben genannten Kontaktinformationen direkt. Fragen die entstehen
 werden hier dann gelistet und beantwortet.

- Es gibt fünf Questbausteine welche im Spiel selbst nicht genutzt werden.
  Sie bestehen entweder aus einer einzelnen Questbinärdatei (.qbn) oder
  einem Questtext (.qrc). Da jeweils der korrespondierende Questbaustein
  fehlt werden diese vom Spiel beim Zugriff nicht korrekt ausgeführt und
  können das Spiel zum Absturz bringen. Aus diesem Grund sind diese für
  Daggerfall Deutsch entfernt wurden.

   80C00Y00 (binary-file) -- eine alternative Questdatei für Malacaths-Quest;
                             beinhaltet dieselben Questtexte wie der Standard-
                             quest
   A0C00Y04 (binary-file) -- beinhaltet denselben Text wie der Imposter-Quest
   M0B40Y04 (text-file)   -- beinhaltet denselben Text wie der entsprechende
                             Kriegergilden-Quest.
   N0C00Y01 (binary-file) -- beinhaltet Texte für einen unfertigen Daedra
                             Verbannungsquest üfr Nichtmitglieder der Magiergilde
   R0C40Y23 (binary-file) -- beinhaltet denselben Text, wie der Daedra-Buchtext
                             und gibt zudem eine falsche Ortsangabe zum
                             Skeffington Coven.
